# Incident 01
An order status page said Shipped without a shipment record. The exception review uses a fixed cut-off of 22 November 2026, 10:00 UTC.
See [[Shipment decision]] and [[Evidence index]].
