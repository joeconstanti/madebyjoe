# Shipment decision
For this practice store, reconcile by order ID and count each shipment ID once. A paid order at least 24 hours old without a shipment needs review. A recent paid order is pending. Exclude refunded orders. Send other payment states to a human. Show Shipped only when a shipment exists.
Scope: this store and its 24-hour window.
Based on [[Incident 01]] and [[Evidence index]].
