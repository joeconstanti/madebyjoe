# Evidence index
- Storefront line 3 (MC-102) is a paid order without a fulfilment record.
- Storefront line 4 (MC-103) is refunded.
- Storefront line 5 (MC-104) is 35 minutes old at the cut-off.
- Fulfilment lines 3 and 4 repeat SHIP-105.
Use the CSVs in the pack to verify these references. See [[Shipment decision]].
