# Incident 02
Review MC-106 in `data/follow-up.csv`. The payment state is chargeback. No shipment is recorded. Use [[Shipment decision]] and cite it, then say what needs a human decision.
