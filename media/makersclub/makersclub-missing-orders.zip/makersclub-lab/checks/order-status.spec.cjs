const { test, expect } = require('@playwright/test');
const { pathToFileURL } = require('node:url');
const { join } = require('node:path');
const app = pathToFileURL(join(__dirname, '../app/index.html')).href;
for (const [order, status] of [
  ['MC-102', 'We’re checking your order'],
  ['MC-104', 'Preparing your order'],
  ['MC-101', 'Shipped'],
]) {
  test(order + ' shows ' + status, async ({ page }) => {
    await page.goto(app + '?order=' + order);
    await expect(page.locator('#status')).toHaveText(status, { timeout: 1500 });
  });
}
