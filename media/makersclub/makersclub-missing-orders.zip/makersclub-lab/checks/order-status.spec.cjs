const { test, expect } = require('@playwright/test');
const { pathToFileURL } = require('node:url');
const { join } = require('node:path');
const app = pathToFileURL(join(__dirname, '../app/index.html')).href;
for (const [order, status, detail] of [
  ['MC-102', 'We’re checking your order', 'We do not have a shipping update yet.'],
  ['MC-104', 'Preparing your order'],
  ['MC-101', 'Shipped'],
]) {
  test(order + ' shows ' + status, async ({ page }) => {
    await page.goto(app + '?order=' + order);
    await expect(page.locator('#status')).toHaveText(status, { timeout: 1500 });
    if (detail) await expect(page.locator('#detail')).toHaveText(detail);
  });
}
