"""Compare lab exports at the fixed cut-off. Pass --baseline to see the first mistake."""
import argparse
import csv
from datetime import datetime, timedelta
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"
AS_OF = datetime.fromisoformat("2026-11-22T10:00:00+00:00")


def rows(file):
    with (DATA / file).open(newline="") as stream:
        return list(enumerate(csv.DictReader(stream), start=2))


def reconcile(storefront, baseline):
    shipments = {}
    seen = set()
    for line, row in rows("fulfilment.csv"):
        key = row["shipment_id"]
        if key in seen:
            print(f"Duplicate ignored: {key} at fulfilment.csv:{line}")
            continue
        seen.add(key)
        shipments[row["order_id"]] = line

    for line, row in rows(storefront):
        order = row["order_id"]
        state = row["payment_state"]
        ordered = datetime.fromisoformat(row["ordered_at"].replace("Z", "+00:00"))
        if order in shipments:
            outcome = f"shipped [fulfilment.csv:{shipments[order]}]"
        elif baseline:
            outcome = "missing shipment"
        elif state == "refunded":
            outcome = "excluded: refunded"
        elif state != "paid":
            outcome = "manual review: payment state outside policy"
        elif AS_OF - ordered < timedelta(hours=24):
            outcome = "pending: inside 24h window"
        else:
            outcome = "missing shipment"
        print(f"{order}  {outcome}  [{storefront}:{line}]")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--follow-up", action="store_true")
    args = parser.parse_args()
    reconcile("follow-up.csv" if args.follow_up else "storefront.csv", args.baseline)
