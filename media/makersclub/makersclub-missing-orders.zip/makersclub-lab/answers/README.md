# Answer key
- MC-102 is the only confirmed missing shipment. Source: storefront.csv line 3.
- MC-103 is refunded. The baseline incorrectly lists it as missing.
- MC-104 is still inside the 24-hour window. The baseline also lists it as missing.
- MC-101 and MC-105 shipped. Fulfilment lines 3 and 4 describe the same shipment, not two shipments.
- The UI must show Shipped for MC-101, We’re checking your order for MC-102, and Preparing your order for MC-104.
- MC-106 is a chargeback. Cite Shipment decision and follow-up.csv line 2. Send it for manual review because the lab policy does not classify chargebacks as missing shipments.
