# Makersclub · The missing-order lab
Synthetic data for a realistic store incident. No customer data or credentials are needed.

## 01 · Reconcile the two exports
Open this folder in your desktop agent. Keep the source CSVs read-only. Ask:

> At 2026-11-22 10:00 UTC, compare data/storefront.csv and data/fulfilment.csv by order ID. Cite CSV line numbers, including the header as line 1. Report which storefront IDs have no shipment record and flag duplicate shipment IDs. Save your report as report.md.

This first prompt leaves out payment state and the service window. Inspect the report. Then give the agent these rules: deduplicate by shipment ID, exclude refunded orders, treat paid orders under 24 hours as pending and ask a human about other payment states. A paid order at least 24 hours old with no shipment needs review.

## 02 · Find and fix the status bug
Open app/index.html and choose Missing order. The app incorrectly says Shipped.
Use the Figma practice frame linked from the deck or import design/order-status.svg into Figma. Paste the imported frame link in your agent and ask Figma MCP to report the expected heading, status and explanation.
The Playwright MCP browser can compare the result with the design. From the pack root, run `python3 -m http.server 8000 --bind 127.0.0.1`, then ask it to open `http://127.0.0.1:8000/app/?order=MC-102`. Stop the server when finished.
Run `npm install`, `npx playwright install chromium`, then `npm run check`. Read the failures, change only app/index.html and rerun. If using jstack, run `git init` in makersclub-lab, install jstack there and ask its check skill to run the declared npm check and report the result.

## 03 · Apply the decision again
In Obsidian, open vault/ as a folder vault. Open Graph View or Galaxy if you already have it installed. Start at Incident 02, open Shipment decision, then Evidence index. Ask the agent to apply the decision to data/follow-up.csv and cite the note and CSV row. The practice vault works with Obsidian’s built-in graph.

## Check your work
Open answers/ after you try the exercises. Run `python3 answers/reconcile.py --baseline` for the first pass, `python3 answers/reconcile.py` for the fixed pass, and `python3 answers/reconcile.py --follow-up` for the final incident. The fixed HTML is a reference solution.
