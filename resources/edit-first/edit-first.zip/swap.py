#!/usr/bin/env python3
"""Move a finished draft edit onto a new voice recording. Python 3.9+, no installs, no API keys.

  python3 swap.py draft_edit.json draft_words.json new_words.json -o new_edit.json --words-out new_captions.json

draft_edit.json   any JSON. Every number called at, until, start, end, duration is a time in seconds
                  on the video timeline and gets moved. Everything else stays the same.
draft_words.json  [{"t": "word", "s": start, "e": end}, ...] for the draft voice
new_words.json    the same for the new take. A raw Whisper result (segments with words) also works.

The words are the anchors. If a line is missing or changed, it stops with exit code 2 and writes nothing.
"""
import argparse, bisect, difflib, json, re, sys
from pathlib import Path

TIME_KEYS = ("at", "until", "start", "end")


def load_words(path):
    d = json.loads(Path(path).read_text())
    if isinstance(d, dict):
        raw = [w for s in d["segments"] for w in s["words"]]
        d = [{"t": w["word"].strip(), "s": w["start"], "e": w["end"]} for w in raw]
    out = []
    for w in d:
        for k, part in enumerate(parts := [p for p in re.split(r"(?<=\w)-(?=\w)|\s+", w["t"]) if p]):
            step = (w["e"] - w["s"]) / len(parts)
            out.append({"t": part, "s": w["s"] + k * step, "e": w["s"] + (k + 1) * step})
    return out


def norm(t):
    return re.sub(r"[^\w]", "", t.replace("%", "percent")).lower()


def match(old, new):
    sm = difflib.SequenceMatcher(None, [norm(w["t"]) for w in old], [norm(w["t"]) for w in new], autojunk=False)
    pairs = [(b.a + k, b.b + k) for b in sm.get_matching_blocks() for k in range(b.size)]
    lost = [(i1, i2) for op, i1, i2, _, _ in sm.get_opcodes() if op in ("delete", "replace")]
    added = [(j1, j2) for op, _, _, j1, j2 in sm.get_opcodes() if op in ("insert", "replace")]
    return pairs, lost, added


def make_map(old, new, pairs):
    """Piecewise-linear map from draft time to new time, through the start and end of every matched word."""
    pts = [(0.0, 0.0)]
    for i, j in pairs:
        for p in ((old[i]["s"], new[j]["s"]), (old[i]["e"], new[j]["e"])):
            if p[0] > pts[-1][0] + 1e-6 and p[1] >= pts[-1][1]:
                pts.append(p)
    xs = [p[0] for p in pts]

    def f(t):
        if t >= xs[-1]:
            return pts[-1][1] + (t - xs[-1])
        k = max(1, bisect.bisect_right(xs, t))
        (x0, y0), (x1, y1) = pts[k - 1], pts[k]
        return y0 + (t - x0) / (x1 - x0) * (y1 - y0)
    return f


def move(node, f, log):
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            if k in TIME_KEYS and isinstance(v, (int, float)) and not isinstance(v, bool):
                out[k] = round(f(v), 3)
                log.append((k, v, out[k]))
            else:
                out[k] = move(v, f, log)
        return out
    return [move(x, f, log) for x in node] if isinstance(node, list) else node


def swap(edit, old, new, max_gap=2):
    pairs, lost, added = match(old, new)
    bad = [" ".join(w["t"] for w in old[a:b]) for a, b in lost if b - a > max_gap]
    extra = [" ".join(w["t"] for w in new[a:b]) for a, b in added if b - a > max_gap]
    if bad or extra or len(pairs) < 0.85 * len(old):
        raise ValueError("\n".join([f"MISSING OR CHANGED: {x}" for x in bad] + [f"NOT IN THE DRAFT: {x}" for x in extra])
                         or "too few matching words")
    f, log = make_map(old, new, pairs), []
    body = {k: v for k, v in edit.items() if k != "duration"}
    out = move(body, f, log)
    tail = max(0.0, edit.get("duration", old[-1]["e"]) - old[-1]["e"])
    out["duration"] = round(new[-1]["e"] + tail, 2)
    j_of = dict(pairs)
    caps = [{"t": w["t"], "s": round(new[j_of[i]]["s"] if i in j_of else f(w["s"]), 3),
             "e": round(new[j_of[i]]["e"] if i in j_of else f(w["e"]), 3)} for i, w in enumerate(old)]
    report = {"words_matched": len(pairs), "words_total": len(old), "times_moved": len(log),
              "largest_move_s": round(max((abs(a - b) for _, a, b in log), default=0), 2),
              "draft_duration": edit.get("duration"), "new_duration": out["duration"],
              "unmatched": [" ".join(w["t"] for w in old[a:b]) for a, b in lost]}
    return out, caps, report, f


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("edit"); ap.add_argument("draft_words"); ap.add_argument("new_words")
    ap.add_argument("-o", "--out", required=True); ap.add_argument("--words-out")
    ap.add_argument("--max-gap", type=int, default=2, help="stop when more words in a row than this do not match")
    a = ap.parse_args()
    try:
        out, caps, report, _ = swap(json.loads(Path(a.edit).read_text()), load_words(a.draft_words), load_words(a.new_words), a.max_gap)
    except ValueError as e:
        print(f"STOPPED. Nothing was written.\n{e}\nRecord the line again, or fix the draft.", file=sys.stderr)
        return 2
    Path(a.out).write_text(json.dumps(out, indent=1))
    if a.words_out:
        Path(a.words_out).write_text(json.dumps(caps, indent=1))
    print(json.dumps(report, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
